<?php 
/**
 * Plugin Name: DarkMode
 * Author:      Yaperson
 * Description: Simple Dark Mode
 * Version:     0.0.0
 */

 /**
  * Add style.css and script.js
  */
function themeslug_enqueue_style() {
    wp_enqueue_style( 'DarkMode-style', plugins_url('/style.css', __FILE__) );
}
 
function themeslug_enqueue_script() {
    wp_enqueue_script( 'DarkMode-js', plugins_url('/DarkMode.js', __FILE__) );
}
 
add_action( 'wp_enqueue_scripts', 'themeslug_enqueue_style' );
add_action( 'wp_enqueue_scripts', 'themeslug_enqueue_script' );