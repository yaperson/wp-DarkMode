var aujourdhui = new Date();
var heures = aujourdhui.getUTCHours() + 2;
var minutes = aujourdhui.getUTCMinutes();
var element = document.body;
var darkModeIsOn = false;

    if (heures > 19 || heures < 7){
        element.classList.add("dark-mode");
        console.log('il est ' + heures + '.' + minutes + 'h Dark mode activé');
        darkModeIsOn = true;
    }
    else {
        element.classList.remove("dark-mode");
        console.log('il est ' + heures + '.' + minutes + 'h et le Dark mode desactivé !');
        darkModeIsOn = false;
    };

function disableDark(){
    element.classList.toggle("dark-mode");
    console.log('il est ' + heures + '.' + minutes + 'h et le Dark mode desactivé !');
    if ( darkModeIsOn = true ){ darkModeIsOn = false }
    else { darkModeIsOn = true }
}

function refresh(){
    var t = 1000; // rafraîchissement en millisecondes
    setTimeout('aujourdhui',t)
}
    refresh();